import Profile from "@/components/dashboard/MyProfile";
import React from "react";

export const metadata = {
  title: "My Profile || Search Homes India Best Real Estate Portal | Buy, Rent, or Sell",
  description: "Search Homes India Best Real Estate Portal | Buy, Rent, or Sell",
};
export default function page() {
  return (
    <>
      <Profile />
    </>
  );
}
